<?php

return [
    'slim' => [
        'settings' => [
            'displayErrorDetails' => true,
        ],
    ],
    'db' => [
        'host' => '',
        'user' => '',
        'pass' => '',
        'name' => '',
    ]
];
